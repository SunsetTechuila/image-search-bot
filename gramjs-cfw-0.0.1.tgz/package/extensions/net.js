export class Socket {
    destroyed;
    connect(...args) { }
    on(...args) { }
    write(...args) { }
    destroy(...args) { }
    unref(...args) { }
}
