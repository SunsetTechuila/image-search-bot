// let _level: string | undefined = undefined;
export var LogLevel;
(function (LogLevel) {
    LogLevel["NONE"] = "none";
    LogLevel["ERROR"] = "error";
    LogLevel["WARN"] = "warn";
    LogLevel["INFO"] = "info";
    LogLevel["DEBUG"] = "debug";
})(LogLevel || (LogLevel = {}));
export class Logger {
    levels = ["error", "warn", "info", "debug"];
    colors;
    messageFormat;
    _logLevel;
    tzOffset;
    constructor(level) {
        // if (!_level) {
        //     _level = level || "info"; // defaults to info
        // }
        this._logLevel = level || LogLevel.INFO;
        this.colors = {
            start: "%c",
            warn: "color : #ff00ff",
            info: "color : #ffff00",
            debug: "color : #00ffff",
            error: "color : #ff0000",
            end: "",
        };
        this.messageFormat = "[%t] [%l] - [%m]";
        this.tzOffset = new Date().getTimezoneOffset() * 60000;
    }
    /**
     *
     * @param level {string}
     * @returns {boolean}
     */
    canSend(level) {
        return this._logLevel
            ? this.levels.indexOf(this._logLevel) >= this.levels.indexOf(level)
            : false;
    }
    /**
     * @param message {string}
     */
    warn(message) {
        this._log(LogLevel.WARN, message, this.colors.warn);
    }
    /**
     * @param message {string}
     */
    info(message) {
        this._log(LogLevel.INFO, message, this.colors.info);
    }
    /**
     * @param message {string}
     */
    debug(message) {
        this._log(LogLevel.DEBUG, message, this.colors.debug);
    }
    /**
     * @param message {string}
     */
    error(message) {
        this._log(LogLevel.ERROR, message, this.colors.error);
    }
    format(message, level) {
        return this.messageFormat
            .replace("%t", this.getDateTime())
            .replace("%l", level.toUpperCase())
            .replace("%m", message);
    }
    get logLevel() {
        return this._logLevel;
    }
    setLevel(level) {
        this._logLevel = level;
    }
    static setLevel(level) {
        console.log("Logger.setLevel is deprecated, it will has no effect. Please, use client.setLogLevel instead.");
    }
    /**
     * @param level {string}
     * @param message {string}
     * @param color {string}
     */
    _log(level, message, color) {
        if (this.canSend(level)) {
            this.log(level, message, color);
        }
        else {
            return;
        }
    }
    /**
     * Override this function for custom Logger. <br />
     *
     * @param level {string}
     * @param message {string}
     * @param color {string}
     */
    log(level, message, color) {
        console.log(this.colors.start + this.format(message, level), color);
    }
    getDateTime() {
        return new Date(Date.now() - this.tzOffset).toISOString().slice(0, -1);
    }
}
