export const SocksClient = {
    createConnection: (x) => { },
};
