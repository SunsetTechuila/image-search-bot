export class TLMessage {
    static SIZE_OVERHEAD = 12;
    static classType = "constructor";
    msgId;
    classType;
    seqNo;
    obj;
    constructor(msgId, seqNo, obj) {
        this.msgId = msgId;
        this.seqNo = seqNo;
        this.obj = obj;
        this.classType = "constructor";
    }
}
