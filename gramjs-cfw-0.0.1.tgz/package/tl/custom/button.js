import { Api } from "../api";
import { utils } from "../../";
export class Button {
    button;
    resize;
    selective;
    singleUse;
    constructor(button, resize, singleUse, selective) {
        this.button = button;
        this.resize = resize;
        this.singleUse = singleUse;
        this.selective = selective;
    }
    static _isInline(button) {
        return (button instanceof Api.KeyboardButtonCallback ||
            button instanceof Api.KeyboardButtonSwitchInline ||
            button instanceof Api.KeyboardButtonUrl ||
            button instanceof Api.KeyboardButtonUrlAuth ||
            button instanceof Api.InputKeyboardButtonUrlAuth);
    }
    static inline(text, data) {
        if (!data) {
            data = Buffer.from(text, "utf-8");
        }
        if (data.length > 64) {
            throw new Error("Too many bytes for the data");
        }
        return new Api.KeyboardButtonCallback({
            text: text,
            data: data,
        });
    }
    static switchInline(text, query = "", samePeer = false) {
        return new Api.KeyboardButtonSwitchInline({
            text,
            query,
            samePeer,
        });
    }
    static url(text, url) {
        return new Api.KeyboardButtonUrl({
            text: text,
            url: url || text,
        });
    }
    static auth(text, url, bot, writeAccess, fwdText) {
        return new Api.InputKeyboardButtonUrlAuth({
            text,
            url: url || text,
            bot: utils.getInputUser(bot || new Api.InputUserSelf()),
            requestWriteAccess: writeAccess,
            fwdText: fwdText,
        });
    }
    static text(text, resize, singleUse, selective) {
        return new this(new Api.KeyboardButton({ text }), resize, singleUse, selective);
    }
    static requestLocation(text, resize, singleUse, selective) {
        return new this(new Api.KeyboardButtonRequestGeoLocation({ text }), resize, singleUse, selective);
    }
    static requestPhone(text, resize, singleUse, selective) {
        return new this(new Api.KeyboardButtonRequestPhone({ text }), resize, singleUse, selective);
    }
    static requestPoll(text, resize, singleUse, selective) {
        return new this(new Api.KeyboardButtonRequestPoll({ text }), resize, singleUse, selective);
    }
    static clear() {
        return new Api.ReplyKeyboardHide({});
    }
    static forceReply() {
        return new Api.ReplyKeyboardForceReply({});
    }
}
