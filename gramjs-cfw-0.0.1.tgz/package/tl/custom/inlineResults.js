import { InlineResult } from "./inlineResult";
export class InlineResults extends Array {
    result;
    queryId;
    cacheTime;
    _validUntil;
    users;
    gallery;
    nextOffset;
    switchPm;
    constructor(client, original, entity) {
        super(...original.results.map((res) => new InlineResult(client, res, original.queryId, entity)));
        this.result = original;
        this.queryId = original.queryId;
        this.cacheTime = original.cacheTime;
        this._validUntil = new Date().getTime() / 1000 + this.cacheTime;
        this.users = original.users;
        this.gallery = Boolean(original.gallery);
        this.nextOffset = original.nextOffset;
        this.switchPm = original.switchPm;
    }
    resultsValid() {
        return new Date().getTime() / 1000 < this._validUntil;
    }
}
