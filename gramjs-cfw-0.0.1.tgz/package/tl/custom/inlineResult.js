import { Api } from "../api";
import { getMessageId } from "../../Utils";
export class InlineResult {
    _ARTICLE = "article";
    _PHOTO = "photo";
    _GIF = "gif";
    _VIDEO = "video";
    _VIDEO_GIF = "mpeg4_gif";
    _AUDIO = "audio";
    _DOCUMENT = "document";
    _LOCATION = "location";
    _VENUE = "venue";
    _CONTACT = "contact";
    _GAME = "game";
    _entity;
    _queryId;
    result;
    _client;
    constructor(client, original, queryId, entity) {
        this._client = client;
        this.result = original;
        this._queryId = queryId;
        this._entity = entity;
    }
    get type() {
        return this.result.type;
    }
    get message() {
        return this.result.sendMessage;
    }
    get description() {
        return this.result.description;
    }
    get url() {
        if (this.result instanceof Api.BotInlineResult) {
            return this.result.url;
        }
    }
    get photo() {
        if (this.result instanceof Api.BotInlineResult) {
            return this.result.thumb;
        }
        else {
            return this.result.photo;
        }
    }
    get document() {
        if (this.result instanceof Api.BotInlineResult) {
            return this.result.content;
        }
        else {
            return this.result.document;
        }
    }
    async click(entity, replyTo, silent = false, clearDraft = false, hideVia = false) {
        if (entity) {
            entity = await this._client.getInputEntity(entity);
        }
        else if (this._entity) {
            entity = this._entity;
        }
        else {
            throw new Error("You must provide the entity where the result should be sent to");
        }
        let replyObject = undefined;
        if (replyTo != undefined) {
            replyObject = new Api.InputReplyToMessage({
                replyToMsgId: getMessageId(replyTo),
            });
        }
        const request = new Api.messages.SendInlineBotResult({
            peer: entity,
            queryId: this._queryId,
            id: this.result.id,
            silent: silent,
            clearDraft: clearDraft,
            hideVia: hideVia,
            replyTo: replyObject,
        });
        return await this._client.invoke(request);
    }
}
