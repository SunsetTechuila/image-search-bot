import { Api } from "../api";
import { getDisplayName, getInputPeer, getPeerId } from "../../Utils";
import { Draft } from "./draft";
import { returnBigInt } from "../../Helpers";
export class Dialog {
    _client;
    dialog;
    pinned;
    folderId;
    archived;
    message;
    date;
    entity;
    inputEntity;
    id;
    name;
    title;
    unreadCount;
    unreadMentionsCount;
    draft;
    isUser;
    isGroup;
    isChannel;
    constructor(client, dialog, entities, message) {
        this._client = client;
        this.dialog = dialog;
        this.pinned = !!dialog.pinned;
        this.folderId = dialog.folderId;
        this.archived = dialog.folderId != undefined;
        this.message = message;
        this.date = this.message.date;
        this.entity = entities.get(getPeerId(dialog.peer));
        this.inputEntity = getInputPeer(this.entity);
        if (this.entity) {
            this.id = returnBigInt(getPeerId(this.entity)); // ^ May be InputPeerSelf();
            this.name = this.title = getDisplayName(this.entity);
        }
        this.unreadCount = dialog.unreadCount;
        this.unreadMentionsCount = dialog.unreadMentionsCount;
        if (!this.entity) {
            throw new Error("Entity not found for dialog");
        }
        this.draft = new Draft(client, this.entity, this.dialog.draft);
        this.isUser = this.entity instanceof Api.User;
        this.isGroup = !!(this.entity instanceof Api.Chat ||
            this.entity instanceof Api.ChatForbidden ||
            (this.entity instanceof Api.Channel && this.entity.megagroup));
        this.isChannel = this.entity instanceof Api.Channel;
    }
}
