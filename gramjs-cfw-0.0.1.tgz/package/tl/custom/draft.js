import { getInputPeer, getPeer } from "../../Utils";
import { Api } from "../api";
export class Draft {
    _client;
    _entity;
    _peer;
    _inputEntity;
    _text;
    _rawText;
    date;
    linkPreview;
    replyToMsgId;
    constructor(client, entity, draft) {
        this._client = client;
        this._peer = getPeer(entity);
        this._entity = entity;
        this._inputEntity = entity ? getInputPeer(entity) : undefined;
        if (!draft || !(draft instanceof Api.DraftMessage)) {
            draft = new Api.DraftMessage({
                message: "",
                date: -1,
            });
        }
        if (!(draft instanceof Api.DraftMessageEmpty)) {
            this.linkPreview = !draft.noWebpage;
            this._text = client.parseMode
                ? client.parseMode.unparse(draft.message, draft.entities || [])
                : draft.message;
            this._rawText = draft.message;
            this.date = draft.date;
            const replyTo = draft.replyTo;
            if (replyTo != undefined) {
                if ("replyToMsgId" in replyTo) {
                    this.replyToMsgId = replyTo.replyToMsgId;
                }
            }
        }
    }
    get entity() {
        return this._entity;
    }
    get inputEntity() {
        if (!this._inputEntity) {
            this._inputEntity = this._client._entityCache.get(this._peer);
        }
        return this._inputEntity;
    }
}
