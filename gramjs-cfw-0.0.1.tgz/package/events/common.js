import { Api } from "../tl";
import { ChatGetter } from "../tl/custom";
import { isArrayLike, returnBigInt } from "../Helpers";
import { utils } from "../";
import { SenderGetter } from "../tl/custom/senderGetter";
import bigInt from "big-integer";
import { parseID } from "../Utils";
/** @hidden */
export async function _intoIdSet(client, chats) {
    if (chats == undefined) {
        return undefined;
    }
    if (!isArrayLike(chats)) {
        chats = [chats];
    }
    const result = new Set();
    for (let chat of chats) {
        if (typeof chat == "number" ||
            typeof chat == "bigint" ||
            (typeof chat == "string" && parseID(chat)) ||
            bigInt.isInstance(chat)) {
            chat = returnBigInt(chat);
            if (chat.lesser(0)) {
                result.add(chat.toString());
            }
            else {
                result.add(utils.getPeerId(new Api.PeerUser({
                    userId: chat,
                })));
                result.add(utils.getPeerId(new Api.PeerChat({
                    chatId: chat,
                })));
                result.add(utils.getPeerId(new Api.PeerChannel({
                    channelId: chat,
                })));
            }
        }
        else if (typeof chat == "object" &&
            chat.SUBCLASS_OF_ID == 0x2d45687) {
            result.add(utils.getPeerId(chat));
        }
        else {
            chat = await client.getInputEntity(chat);
            if (chat instanceof Api.InputPeerSelf) {
                chat = await client.getMe(true);
            }
            result.add(utils.getPeerId(chat));
        }
    }
    return Array.from(result);
}
/**
 * The common event builder, with builtin support to filter per chat.<br/>
 * All events inherit this.
 */
export class EventBuilder {
    chats;
    blacklistChats;
    resolved;
    func;
    client;
    constructor(eventParams) {
        this.chats = eventParams.chats?.map((x) => x.toString());
        this.blacklistChats = eventParams.blacklistChats || false;
        this.resolved = false;
        this.func = eventParams.func;
    }
    build(update, callback, selfId) {
        if (update)
            return update;
    }
    async resolve(client) {
        if (this.resolved) {
            return;
        }
        await this._resolve(client);
        this.resolved = true;
    }
    async _resolve(client) {
        this.chats = await _intoIdSet(client, this.chats);
    }
    filter(event) {
        if (!this.resolved) {
            return;
        }
        if (this.chats != undefined) {
            if (event.chatId == undefined) {
                return;
            }
            const inside = this.chats.includes(event.chatId.toString());
            if (inside == this.blacklistChats) {
                // If this chat matches but it's a blacklist ignore.
                // If it doesn't match but it's a whitelist ignore.
                return;
            }
        }
        if (this.func && !this.func(event)) {
            return;
        }
        return event;
    }
}
export class EventCommon extends ChatGetter {
    _eventName = "Event";
    _entities;
    _messageId;
    constructor({ chatPeer = undefined, msgId = undefined, broadcast = undefined, }) {
        super();
        ChatGetter.initChatClass(this, { chatPeer, broadcast });
        this._entities = new Map();
        this._client = undefined;
        this._messageId = msgId;
    }
    _setClient(client) {
        this._client = client;
    }
    get client() {
        return this._client;
    }
}
export class EventCommonSender extends SenderGetter {
    _eventName = "Event";
    _entities;
    _messageId;
    constructor({ chatPeer = undefined, msgId = undefined, broadcast = undefined, }) {
        super();
        ChatGetter.initChatClass(this, { chatPeer, broadcast });
        SenderGetter.initChatClass(this, { chatPeer, broadcast });
        this._entities = new Map();
        this._client = undefined;
        this._messageId = msgId;
    }
    _setClient(client) {
        this._client = client;
    }
    get client() {
        return this._client;
    }
}
