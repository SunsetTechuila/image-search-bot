import { version } from "../";
import { sleep } from "../Helpers";
import { ConnectionTCPFull, } from "../network/connection";
import { Session } from "../sessions";
import { Logger, PromisedWebSockets } from "../extensions";
import { Api } from "../tl";
import os from "./os";
import { EntityCache } from "../entityCache";
import { MarkdownParser } from "../extensions/markdown";
import { MTProtoSender } from "../network";
import { LAYER } from "../tl/AllTLObjects";
import { ConnectionTCPMTProxyAbridged, } from "../network/connection/TCPMTProxy";
import { Semaphore } from "async-mutex";
import { LogLevel } from "../extensions/Logger";
import Deferred from "../extensions/Deferred";
const EXPORTED_SENDER_RECONNECT_TIMEOUT = 1000; // 1 sec
const EXPORTED_SENDER_RELEASE_TIMEOUT = 30000; // 30 sec
const DEFAULT_DC_ID = 4;
const DEFAULT_IPV4_IP = "149.154.167.91";
const DEFAULT_IPV6_IP = "2001:067c:04e8:f004:0000:0000:0000:000a";
const clientParamsDefault = {
    connection: ConnectionTCPFull,
    networkSocket: PromisedWebSockets,
    useIPV6: false,
    timeout: 10,
    requestRetries: 5,
    connectionRetries: Infinity,
    retryDelay: 1000,
    downloadRetries: 5,
    autoReconnect: true,
    sequentialUpdates: false,
    floodSleepThreshold: 60,
    deviceModel: "",
    systemVersion: "",
    appVersion: "",
    langCode: "en",
    systemLangCode: "en",
    _securityChecks: true,
    useWSS: false,
    testServers: false,
};
export class TelegramBaseClient {
    /** The current gramJS version. */
    __version__ = version;
    /** @hidden */
    _config;
    /** @hidden */
    _log;
    /** @hidden */
    _floodSleepThreshold;
    session;
    apiHash;
    apiId;
    /** @hidden */
    _requestRetries;
    /** @hidden */
    _downloadRetries;
    /** @hidden */
    _connectionRetries;
    /** @hidden */
    _retryDelay;
    /** @hidden */
    _timeout;
    /** @hidden */
    _autoReconnect;
    /** @hidden */
    _connection;
    /** @hidden */
    _initRequest;
    /** @hidden */
    _sender;
    /** @hidden */
    _floodWaitedRequests;
    /** @hidden */
    _borrowedSenderPromises;
    /** @hidden */
    _bot;
    /** @hidden */
    _useIPV6;
    /** @hidden */
    _selfInputPeer;
    /** @hidden */
    useWSS;
    /** @hidden */
    _errorHandler;
    /** @hidden */
    _eventBuilders;
    /** @hidden */
    _entityCache;
    /** @hidden */
    _lastRequest;
    /** @hidden */
    _parseMode;
    /** @hidden */
    _ALBUMS = new Map();
    /** @hidden */
    _exportedSenderPromises = new Map();
    /** @hidden */
    _exportedSenderReleaseTimeouts = new Map();
    /** @hidden */
    _loopStarted;
    /** @hidden */
    _reconnecting;
    /** @hidden */
    _destroyed;
    /** @hidden */
    _isSwitchingDc;
    /** @hidden */
    _proxy;
    /** @hidden */
    _semaphore;
    /** @hidden */
    _securityChecks;
    /** @hidden */
    testServers;
    /** @hidden */
    networkSocket;
    _connectedDeferred;
    constructor(session, apiId, apiHash, clientParams) {
        clientParams = { ...clientParamsDefault, ...clientParams };
        if (!apiId || !apiHash) {
            throw new Error("Your API ID or Hash cannot be empty or undefined");
        }
        if (clientParams.baseLogger) {
            this._log = clientParams.baseLogger;
        }
        else {
            this._log = new Logger();
        }
        this._log.info("Running gramJS version " + version);
        if (!(session instanceof Session)) {
            throw new Error("Only StringSession is supported currently :( ");
        }
        this._floodSleepThreshold = clientParams.floodSleepThreshold;
        this.session = session;
        this.apiId = apiId;
        this.apiHash = apiHash;
        this._useIPV6 = clientParams.useIPV6;
        this._requestRetries = clientParams.requestRetries;
        this._downloadRetries = clientParams.downloadRetries;
        this._connectionRetries = clientParams.connectionRetries;
        this._retryDelay = clientParams.retryDelay || 0;
        this._timeout = clientParams.timeout;
        this._autoReconnect = clientParams.autoReconnect;
        this._proxy = clientParams.proxy;
        this._semaphore = new Semaphore(clientParams.maxConcurrentDownloads || 1);
        this.testServers = clientParams.testServers || false;
        this.networkSocket = PromisedWebSockets;
        if (!(clientParams.connection instanceof Function)) {
            throw new Error("Connection should be a class not an instance");
        }
        this._connection = clientParams.connection;
        let initProxy;
        if (this._proxy?.MTProxy) {
            this._connection = ConnectionTCPMTProxyAbridged;
            initProxy = new Api.InputClientProxy({
                address: this._proxy.ip,
                port: this._proxy.port,
            });
        }
        this._initRequest = new Api.InitConnection({
            apiId: this.apiId,
            deviceModel: clientParams.deviceModel || os.type().toString() || "Unknown",
            systemVersion: clientParams.systemVersion || os.release().toString() || "1.0",
            appVersion: clientParams.appVersion || "1.0",
            langCode: clientParams.langCode,
            langPack: "",
            systemLangCode: clientParams.systemLangCode,
            proxy: initProxy,
        });
        this._eventBuilders = [];
        this._floodWaitedRequests = {};
        this._borrowedSenderPromises = {};
        this._bot = undefined;
        this._selfInputPeer = undefined;
        this.useWSS = clientParams.useWSS;
        this._securityChecks = !!clientParams.securityChecks;
        if (this.useWSS && this._proxy) {
            throw new Error("Cannot use SSL with proxies. You need to disable the useWSS client param in TelegramClient");
        }
        this._entityCache = new EntityCache();
        // These will be set later
        this._config = undefined;
        this._loopStarted = false;
        this._reconnecting = false;
        this._destroyed = false;
        this._isSwitchingDc = false;
        this._connectedDeferred = new Deferred();
        // parse mode
        this._parseMode = MarkdownParser;
    }
    get floodSleepThreshold() {
        return this._floodSleepThreshold;
    }
    set floodSleepThreshold(value) {
        this._floodSleepThreshold = Math.min(value || 0, 24 * 60 * 60);
    }
    set maxConcurrentDownloads(value) {
        // @ts-ignore
        this._semaphore._value = value;
    }
    // region connecting
    async _initSession() {
        await this.session.load();
        if (!this.session.serverAddress) {
            this.session.setDC(DEFAULT_DC_ID, this._useIPV6 ? DEFAULT_IPV6_IP : DEFAULT_IPV4_IP, this.useWSS ? 443 : 80);
        }
        else {
            this._useIPV6 = this.session.serverAddress.includes(":");
        }
    }
    get connected() {
        return this._sender && this._sender.isConnected();
    }
    async disconnect() {
        await this._disconnect();
        await Promise.all(Object.values(this._exportedSenderPromises)
            .map((promises) => {
            return Object.values(promises).map((promise) => {
                return (promise &&
                    promise.then((sender) => {
                        if (sender) {
                            return sender.disconnect();
                        }
                        return undefined;
                    }));
            });
        })
            .flat());
        Object.values(this._exportedSenderReleaseTimeouts).forEach((timeouts) => {
            Object.values(timeouts).forEach((releaseTimeout) => {
                clearTimeout(releaseTimeout);
            });
        });
        this._exportedSenderPromises.clear();
    }
    get disconnected() {
        return !this._sender || this._sender._disconnected;
    }
    async _disconnect() {
        await this._sender?.disconnect();
    }
    /**
     * Disconnects all senders and removes all handlers
     * Disconnect is safer as it will not remove your event handlers
     */
    async destroy() {
        this._destroyed = true;
        await Promise.all([
            this.disconnect(),
            ...Object.values(this._borrowedSenderPromises).map((promise) => {
                return promise.then((sender) => sender.disconnect());
            }),
        ]);
        this._eventBuilders = [];
    }
    /** @hidden */
    async _authKeyCallback(authKey, dcId) {
        this.session.setAuthKey(authKey, dcId);
        await this.session.save();
    }
    /** @hidden */
    async _cleanupExportedSender(dcId) {
        if (this.session.dcId !== dcId) {
            this.session.setAuthKey(undefined, dcId);
        }
        let sender = await this._exportedSenderPromises.get(dcId);
        this._exportedSenderPromises.delete(dcId);
        await sender?.disconnect();
    }
    /** @hidden */
    async _connectSender(sender, dcId) {
        // if we don't already have an auth key we want to use normal DCs not -1
        const dc = await this.getDC(dcId, !!sender.authKey.getKey());
        while (true) {
            try {
                await sender.connect(new this._connection({
                    ip: dc.ipAddress,
                    port: dc.port,
                    dcId: dcId,
                    loggers: this._log,
                    proxy: this._proxy,
                    testServers: this.testServers,
                    socket: this.networkSocket,
                }), false);
                if (this.session.dcId !== dcId && !sender._authenticated) {
                    this._log.info(`Exporting authorization for data center ${dc.ipAddress} with layer ${LAYER}`);
                    const auth = await this.invoke(new Api.auth.ExportAuthorization({ dcId: dcId }));
                    this._initRequest.query = new Api.auth.ImportAuthorization({
                        id: auth.id,
                        bytes: auth.bytes,
                    });
                    const req = new Api.InvokeWithLayer({
                        layer: LAYER,
                        query: this._initRequest,
                    });
                    await sender.send(req);
                    sender._authenticated = true;
                }
                sender.dcId = dcId;
                sender.userDisconnected = false;
                return sender;
            }
            catch (err) {
                if (err.errorMessage === "DC_ID_INVALID") {
                    sender._authenticated = true;
                    sender.userDisconnected = false;
                    return sender;
                }
                if (this._errorHandler) {
                    await this._errorHandler(err);
                }
                else if (this._log.canSend(LogLevel.ERROR)) {
                    console.error(err);
                }
                await sleep(1000);
                await sender.disconnect();
            }
        }
    }
    /** @hidden */
    async _borrowExportedSender(dcId, shouldReconnect, existingSender) {
        if (!this._exportedSenderPromises.get(dcId) || shouldReconnect) {
            this._exportedSenderPromises.set(dcId, this._connectSender(existingSender || this._createExportedSender(dcId), dcId));
        }
        let sender;
        try {
            sender = await this._exportedSenderPromises.get(dcId);
            if (!sender.isConnected()) {
                if (sender.isConnecting) {
                    await sleep(EXPORTED_SENDER_RECONNECT_TIMEOUT);
                    return this._borrowExportedSender(dcId, false, sender);
                }
                else {
                    return this._borrowExportedSender(dcId, true, sender);
                }
            }
        }
        catch (err) {
            if (this._errorHandler) {
                await this._errorHandler(err);
            }
            if (this._log.canSend(LogLevel.ERROR)) {
                console.error(err);
            }
            return this._borrowExportedSender(dcId, true);
        }
        if (this._exportedSenderReleaseTimeouts.get(dcId)) {
            clearTimeout(this._exportedSenderReleaseTimeouts.get(dcId));
            this._exportedSenderReleaseTimeouts.delete(dcId);
        }
        this._exportedSenderReleaseTimeouts.set(dcId, setTimeout(() => {
            this._exportedSenderReleaseTimeouts.delete(dcId);
            sender.disconnect();
        }, EXPORTED_SENDER_RELEASE_TIMEOUT));
        return sender;
    }
    /** @hidden */
    _createExportedSender(dcId) {
        return new MTProtoSender(this.session.getAuthKey(dcId), {
            logger: this._log,
            dcId,
            retries: this._connectionRetries,
            delay: this._retryDelay,
            autoReconnect: this._autoReconnect,
            connectTimeout: this._timeout,
            authKeyCallback: this._authKeyCallback.bind(this),
            isMainSender: dcId === this.session.dcId,
            onConnectionBreak: this._cleanupExportedSender.bind(this),
            client: this,
            securityChecks: this._securityChecks,
        });
    }
    /** @hidden */
    getSender(dcId) {
        return dcId
            ? this._borrowExportedSender(dcId)
            : Promise.resolve(this._sender);
    }
    // endregion
    async getDC(dcId, download) {
        throw new Error("Cannot be called from here!");
    }
    invoke(request) {
        throw new Error("Cannot be called from here!");
    }
    setLogLevel(level) {
        this._log.setLevel(level);
    }
    get logger() {
        return this._log;
    }
    /**
     * Custom error handler for the client
     * @example
     * ```ts
     * client.onError = async (error)=>{
     *         console.log("error is",error)
     *     }
     * ```
     */
    set onError(handler) {
        this._errorHandler = async (error) => {
            try {
                await handler(error);
            }
            catch (e) {
                if (this._log.canSend(LogLevel.ERROR)) {
                    e.message = `Error ${e.message} thrown while handling top-level error: ${error.message}`;
                    console.error(e);
                }
            }
        };
    }
}
