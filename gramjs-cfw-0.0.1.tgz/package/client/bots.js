import { Api } from "../tl";
import { InlineResults } from "../tl/custom/inlineResults";
var GetInlineBotResults = Api.messages.GetInlineBotResults;
// BotMethods
/** @hidden */
export async function inlineQuery(client, bot, query, entity, offset, geoPoint) {
    bot = await client.getInputEntity(bot);
    let peer = new Api.InputPeerSelf();
    if (entity) {
        peer = await client.getInputEntity(entity);
    }
    const result = await client.invoke(new GetInlineBotResults({
        bot: bot,
        peer: peer,
        query: query,
        offset: offset || "",
        geoPoint: geoPoint,
    }));
    return new InlineResults(client, result, entity ? peer : undefined);
}
