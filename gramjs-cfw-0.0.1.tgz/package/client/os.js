export default {
    type: () => {
        return "Cloudflare Worker";
    },
    release: () => {
        return "1.0";
    },
};
