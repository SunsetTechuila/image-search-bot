import { getPeerId, sanitizeParseMode } from "../Utils";
import { Api } from "../tl/api";
import { utils } from "../index";
import { _EntityType, _entityType, isArrayLike } from "../Helpers";
import bigInt from "big-integer";
export const DEFAULT_DELIMITERS = {
    "**": Api.MessageEntityBold,
    __: Api.MessageEntityItalic,
    "~~": Api.MessageEntityStrike,
    "`": Api.MessageEntityCode,
    "```": Api.MessageEntityPre,
};
/** @hidden */
export async function _replaceWithMention(client, entities, i, user) {
    try {
        entities[i] = new Api.InputMessageEntityMentionName({
            offset: entities[i].offset,
            length: entities[i].length,
            userId: (await client.getInputEntity(user)),
        });
        return true;
    }
    catch (e) {
        return false;
    }
}
/** @hidden */
export async function _parseMessageText(client, message, parseMode) {
    if (parseMode == false) {
        return [message, []];
    }
    if (parseMode == undefined) {
        if (client.parseMode == undefined) {
            return [message, []];
        }
        parseMode = client.parseMode;
    }
    else if (typeof parseMode === "string") {
        parseMode = sanitizeParseMode(parseMode);
    }
    const [rawMessage, msgEntities] = parseMode.parse(message);
    for (let i = msgEntities.length - 1; i >= 0; i--) {
        const e = msgEntities[i];
        if (e instanceof Api.MessageEntityTextUrl) {
            const m = /^@|\+|tg:\/\/user\?id=(\d+)/.exec(e.url);
            if (m) {
                const userIdOrUsername = m[1] ? Number(m[1]) : e.url;
                const isMention = await _replaceWithMention(client, msgEntities, i, userIdOrUsername);
                if (!isMention) {
                    msgEntities.splice(i, 1);
                }
            }
        }
    }
    return [rawMessage, msgEntities];
}
/** @hidden */
export function _getResponseMessage(client, request, result, inputChat) {
    let updates = [];
    let entities = new Map();
    if (result instanceof Api.UpdateShort) {
        updates = [result.update];
    }
    else if (result instanceof Api.Updates ||
        result instanceof Api.UpdatesCombined) {
        updates = result.updates;
        for (const x of [...result.users, ...result.chats]) {
            entities.set(utils.getPeerId(x), x);
        }
    }
    else {
        return;
    }
    const randomToId = new Map();
    const idToMessage = new Map();
    let schedMessage;
    for (const update of updates) {
        if (update instanceof Api.UpdateMessageID) {
            randomToId.set(update.randomId.toString(), update.id);
        }
        else if (update instanceof Api.UpdateNewChannelMessage ||
            update instanceof Api.UpdateNewMessage) {
            update.message._finishInit(client, entities, inputChat);
            if ("randomId" in request || isArrayLike(request)) {
                idToMessage.set(update.message.id, update.message);
            }
            else {
                return update.message;
            }
        }
        else if (update instanceof Api.UpdateEditMessage &&
            "peer" in request &&
            _entityType(request.peer) != _EntityType.CHANNEL) {
            update.message._finishInit(client, entities, inputChat);
            if ("randomId" in request) {
                idToMessage.set(update.message.id, update.message);
            }
            else if ("id" in request && request.id === update.message.id) {
                return update.message;
            }
        }
        else if (update instanceof Api.UpdateEditChannelMessage &&
            "peer" in request &&
            getPeerId(request.peer) ==
                getPeerId(update.message.peerId)) {
            if (request.id == update.message.id) {
                update.message._finishInit(client, entities, inputChat);
                return update.message;
            }
        }
        else if (update instanceof Api.UpdateNewScheduledMessage) {
            update.message._finishInit(client, entities, inputChat);
            schedMessage = update.message;
            idToMessage.set(update.message.id, update.message);
        }
        else if (update instanceof Api.UpdateMessagePoll) {
            if (request.media.poll.id == update.pollId) {
                const m = new Api.Message({
                    id: request.id,
                    peerId: utils.getPeerId(request.peer),
                    media: new Api.MessageMediaPoll({
                        poll: update.poll,
                        results: update.results,
                    }),
                    message: "",
                    date: 0,
                });
                m._finishInit(client, entities, inputChat);
                return m;
            }
        }
    }
    if (request == undefined) {
        return idToMessage;
    }
    let randomId;
    if (isArrayLike(request) ||
        typeof request == "number" ||
        bigInt.isInstance(request)) {
        randomId = request;
    }
    else {
        randomId = request.randomId;
    }
    if (!randomId) {
        if (schedMessage) {
            return schedMessage;
        }
        client._log.warn(`No randomId in ${request} to map to. returning undefined for ${result}`);
        return undefined;
    }
    if (!isArrayLike(randomId)) {
        let msg = idToMessage.get(randomToId.get(randomId.toString()));
        if (!msg) {
            client._log.warn(`Request ${request.className} had missing message mapping ${result.className}`);
        }
        return msg;
    }
    const final = [];
    let warned = false;
    for (const rnd of randomId) {
        const tmp = randomToId.get(rnd.toString());
        if (!tmp) {
            warned = true;
            break;
        }
        const tmp2 = idToMessage.get(tmp);
        if (!tmp2) {
            warned = true;
            break;
        }
        final.push(tmp2);
    }
    if (warned) {
        client._log.warn(`Request ${request.className} had missing message mapping ${result.className}`);
    }
    const finalToReturn = [];
    for (const rnd of randomId) {
        finalToReturn.push(idToMessage.get(randomToId.get(rnd.toString())));
    }
    return finalToReturn;
}
