export { MTProtoPlainSender } from "./MTProtoPlainSender";
export { doAuthentication } from "./Authenticator";
export { MTProtoSender } from "./MTProtoSender";
export class UpdateConnectionState {
    static disconnected = -1;
    static connected = 1;
    static broken = 0;
    state;
    constructor(state) {
        this.state = state;
    }
}
export { Connection, ConnectionTCPFull, ConnectionTCPAbridged, ConnectionTCPObfuscated, } from "./connection";
