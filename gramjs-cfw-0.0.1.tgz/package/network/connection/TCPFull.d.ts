/// <reference types="node" />
import { Buffer } from 'node:buffer';
import { Connection, PacketCodec } from "./Connection";
import type { PromisedWebSockets } from "../../extensions";
export declare class FullPacketCodec extends PacketCodec {
    private _sendCounter;
    constructor(connection: any);
    encodePacket(data: Buffer): Buffer;
    /**
     *
     * @param reader {PromisedWebSockets}
     * @returns {Promise<*>}
     */
    readPacket(reader: PromisedWebSockets): Promise<Buffer>;
}
export declare class ConnectionTCPFull extends Connection {
    PacketCodecClass: typeof FullPacketCodec;
}
